package ch06.sec07.exam01;

public class Car {
    String model;
    String color;
    int maxSpeed;

    Car(String model, String color, int maxSpeed) {

    }
}
